CREATE INDEX LookUpTrades ON Trades(buyerID,sellerID);
